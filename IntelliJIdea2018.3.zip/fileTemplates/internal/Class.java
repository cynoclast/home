package ${PACKAGE_NAME};

/**
 * 
 * @author Trampas Kirk
 */
public class ${NAME} {
}
