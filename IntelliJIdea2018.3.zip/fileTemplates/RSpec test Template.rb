#parse("Ruby File Header.rb")

require "spec"

describe ${Behaviour_Name} do

  # Called before each example.
  before(:each) do
    # Do nothing
  end

  # Called after each example.
  after(:each) do
    # Do nothing
  end

  it "should ${it_should}" do

    #To change this template use File | Settings | File Templates.
    true.should == false
  end
end