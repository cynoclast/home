package ${PACKAGE_NAME};

/**
 * <shametag>Trampas Kirk was too lazy to javadoc this. Make him do it.</shametag>
 * @author 
 */
public class ${Name}{
    private static ${Name} ourInstance = new ${Name}();

    public static ${Name} getInstance() {
        return ourInstance;
    }

    private ${Name}() {
    }
}
