package ${PACKAGE_NAME};

/**
 * 
 * @author Trampas Kirk - trampas.kirk@nike.com
 */
public interface ${NAME} {
}
